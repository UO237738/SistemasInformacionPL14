package Controlador;

public class ControladorGestionInscripcionActividad {

}
