package Vista;

public class VIstaGestionInscripcionActividad {

}
