package Modelo;

public class ModeloGestionInscripcionActividad {

}
